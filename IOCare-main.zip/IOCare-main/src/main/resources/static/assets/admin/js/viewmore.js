app.controller('viewmore', function($scope) {
  $scope.items = [
    {
      loaiChiendich: 'Project Apollo',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Done',
      phanLoai: 'Vanessa Tucker',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Apollo',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Done',
      phanLoai: 'Vanessa Tucker',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Fireball',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'Cancelled',
      phanLoai: 'William Harris',
      nhanSu: '',
      thoiGianChamSoc: ''
    },
    {
      loaiChiendich: 'Project Nitro',
      maSinhVien: '01/01/2021',
      lyDo: '31/06/2021',
      dienGiai: 'In progress',
      phanLoai: 'Vanessa Tucker',
      nhanSu: '',
      thoiGianChamSoc: ''
    }
  ];

  $scope.visibleItems = 10;

  $scope.showMore = function() {
    $scope.visibleItems += 10; // Thay đổi số lượng hiển thị khi nhấp vào nút "Xem thêm"
  };
});