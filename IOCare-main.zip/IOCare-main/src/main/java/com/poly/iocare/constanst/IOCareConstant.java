package com.poly.iocare.constanst;

public class IOCareConstant {
	public final static String ADMIN_INDEX = "admin/index";
}
