//package com.fpoly.iocare.controller.admin;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//@Controller
//public class AuthController {
//	/*--url trang đăng nhập--*/
//	@RequestMapping("")
//	public String loginForm() {
//		return "admin/index";
//	}
//}
